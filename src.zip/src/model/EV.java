package model;

public class EV {

    public static String ID;
    public static String Na;
    public static String email;
    public static String phone;
    public static String pwd;

    public static String SelectN;
    public static String SelectID;
}
